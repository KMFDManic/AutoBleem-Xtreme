#include <stdio.h>

int main(int argc, char* argv[])
{
	FILE* fp = fopen("turbo.art", "wt");

	if (fp != NULL)
	{
		int i, j;
		int n;

		fprintf(fp,
			"Panel:\n"
			"\tfile     = panel.png\n"
			"\tlayer    = panel\n"
			"\tposition = 0, -59, 248, 0\n"
			"\tpriority = -1\n"
			"\tvisible  = 1\n"
			"\n");

		for (i = 0; i <= 10; i++)
		{
			fprintf(fp,
				"Speed%02d:\n"
				"\tfile     = speed%02d.png\n"
				"\tlayer    = panel\n"
				"\tposition = 17, -51, 30, -8\n"
				"\tvisible  = 0\n"
				"\n",
				i, i);
		}

		for (i = 0; i < 5; i++)
		{
			for (j = 0; j <= 10; j++)
			{
				char c = (j == 10) ? 'X' : '0' + j;

				fprintf(fp,
					"LED%02d-%c:\n"
					"\tfile     = digit%c.png\n"
					"\tlayer    = panel\n"
					"\tposition = %d, %d, %d, %d\n"
					"\tvisible  = 0\n"
					"\n",
					27 + i, c, c,
					217, - 8 - i * 9 - 7,
					230, - 8 - i * 9 - 0);
			}
		}

		for (n = 0; n < 5; n++)
		{
			int y1 = 128 + 15 * n;
			int y2 = 138 + 15 * n;

			for (i = 0; i < 5; i++)
			{
				for (j = 0; j <= 10; j++)
				{
					char c = (j == 10) ? 'X' : '0' + j;

					fprintf(fp,
						"LED%02d-%c:\n"
						"\tfile     = digit%c.png\n"
						"\tlayer    = panel\n"
						"\tposition = %d, %d, %d, %d\n"
						"\tvisible  = 0\n"
						"\n",
						2 + 5 * n + i, c, c,
						y1, - 15 - i * 6 - 5,
						y2, - 15 - i * 6 - 0);
				}
			}
		}

		fclose(fp);
	}

	return 0;
}
