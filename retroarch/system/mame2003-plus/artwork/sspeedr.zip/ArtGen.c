#include <stdio.h>

int main(int argc, char* argv[])
{
	FILE* fp = fopen("sspeedr.art", "wt");

	if (fp != NULL)
	{
		int i, j;
		int n;

		fprintf(fp,
			"Panel:\n"
			"\tfile     = panel.png\n"
			"\tlayer    = panel\n"
			"\tposition = 0, -148, 376, 0\n"
			"\tpriority = -1\n"
			"\tvisible  = 1\n"
			"\n");

		fprintf(fp,
			"lampGO:\n"
			"\tfile     = lampGO.png\n"
			"\tlayer    = panel\n"
			"\tposition = 8, -65, 21, -8\n"
			"\tpriority = 0\n"
			"\tvisible  = 0\n"
			"\n");

		fprintf(fp,
			"lampEP:\n"
			"\tfile     = lampEP.png\n"
			"\tlayer    = panel\n"
			"\tposition = 8, -141, 21, -66\n"
			"\tpriority = 0\n"
			"\tvisible  = 0\n"
			"\n");

		for (i = 0; i < 2; i++)
		{
			for (j = 0; j <= 10; j++)
			{
				char c = (j == 10) ? 'X' : '0' + j;

				fprintf(fp,
					"LEDT%d-%c:\n"
					"\tfile     = digit%c.png\n"
					"\tlayer    = panel\n"
					"\tposition = %d, %d, %d, %d\n"
					"\tvisible  = 0\n"
					"\n",
					i, c, c,
					 93, -116 + i * 14 + 0,
					112, -116 + i * 14 + 10);
			}
		}

		for (n = 0; n < 5; n++)
		{
			for (i = 0; i < 4; i++)
			{
				for (j = 0; j <= 10; j++)
				{
					char c = (j == 10) ? 'X' : '0' + j;

					fprintf(fp,
						"LED%02d-%c:\n"
						"\tfile     = digit%c.png\n"
						"\tlayer    = panel\n"
						"\tposition = %d, %d, %d, %d\n"
						"\tvisible  = 0\n"
						"\n",
						4 * n + i, c, c,
						324 - 27 * n, -130 + i * 14 + 0,
						343 - 27 * n, -130 + i * 14 + 10);
				}
			}
		}

		for (i = 0; i < 4; i++)
		{
			for (j = 0; j <= 10; j++)
			{
				char c = (j == 10) ? 'X' : '0' + j;

				fprintf(fp,
					"LED%02d-%c:\n"
					"\tfile     = digit%c.png\n"
					"\tlayer    = panel\n"
					"\tposition = %d, %d, %d, %d\n"
					"\tvisible  = 0\n"
					"\n",
					20 + i, c, c,
					324 - 142, -130 + i * 14 + 0,
					343 - 142, -130 + i * 14 + 10);
			}
		}

		fclose(fp);
	}

	return 0;
}
